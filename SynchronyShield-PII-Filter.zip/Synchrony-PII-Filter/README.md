# PII Filter Chrome Extension

A Chrome extension that automatically detects and redacts personally identifiable information (PII) in web forms and text inputs to prevent accidental exposure of sensitive data.

## Features

- **Real-time PII Detection**: Scans input fields as you type
- **Multiple PII Types**: Detects SSNs, emails, credit cards, phone numbers, and password fields
- **Custom Phrases**: Add your own phrases to be automatically redacted
- **Automatic Redaction**: Replaces detected PII with redacted placeholders
- **Visual Notifications**: Shows alerts when PII is detected and redacted
- **Configurable Settings**: Toggle filtering on/off and set security levels
- **Cross-site Protection**: Works on all websites and web applications

## Detected PII Types

| Type | Example | Redacted As |
|------|---------|-------------|
| Social Security Number | 123-45-6789 | [REDACTED-SSN] |
| Email Address | user@example.com | [REDACTED-EMAIL] |
| Credit Card | 4111 1111 1111 1111 | [REDACTED-CREDIT-CARD] |
| Phone Number | (123) 456-7890 | [REDACTED-PHONE] |
| Password Fields | `<input type="password">` | [REDACTED-PASSWORD] |
| Custom Phrases | Your custom phrases | [REDACTED-CUSTOM] |


- The following prompt is AI Generated and can be used for testing redaction: During the quarterly marketing sync, Jessica noted that the campaign reach exceeded 4.2 million impressions, which was well beyond expectations. To follow up, please reach out to Marcus at marcus_blake93@notrealmail.net or call him at (502) 391-8740. For system access, use the dummy credentials provided in the shared folder. Just make sure you don't use placeholder SSNs like 123-45-6789 or 092-73-1548 in the test database again. Meanwhile, Emily’s contact is emily.jones42@mockemail.org, and her backup line is 312-555-9981 in case the main one fails. Don't forget to update the invoice IDs before sending them to payroll. Also, remove any entries that include SSNs like 867-53-0912 or dummy numbers such as 000-00-0000, as these are only for mock testing.

## Installation

### Development Installation

1. **Clone or download** this repository to your local machine

2. **Open Chrome** and navigate to `chrome://extensions/`

3. **Enable Developer Mode** by toggling the switch in the top-right corner

4. **Click "Load unpacked"** and select the folder containing this extension

5. **The extension should now appear** in your extensions list and be active

### Icon Setup

Before loading the extension, you'll need to add actual icon files:

1. Replace the placeholder files in the `icons/` directory with actual PNG images:
   - `icons/icon16.png` (16x16 pixels)
   - `icons/icon48.png` (48x48 pixels) 
   - `icons/icon128.png` (128x128 pixels)

2. You can create simple icons or use any security/privacy-themed icons

## Usage

### Basic Usage

1. **Install the extension** following the installation steps above

2. **The extension is enabled by default** and will start scanning immediately

3. **Try entering PII** in any web form:
   - Type an SSN like `123-45-6789`
   - Enter an email like `test@example.com`
   - Input a credit card number
   - Type a phone number

4. **Watch the redaction** - the extension will automatically replace the PII with redacted placeholders

### Custom Phrases

You can add your own phrases to be automatically redacted:

1. **Open the extension settings** by clicking the extension icon and selecting "Open Settings"

2. **Go to the "Custom Phrases" section**

3. **Add a phrase**:
   - Enter the phrase you want to filter (e.g., "company secret", "internal only")
   - Set the replacement text (defaults to `[REDACTED-CUSTOM]`)
   - Click "Add Phrase"

4. **Test your custom phrases** by typing them in any text field

**Features of Custom Phrases:**
- Case-insensitive matching
- Partial text matching (if you type "secret", it will match "company secret")
- Custom replacement text
- Edit and delete existing phrases
- Sync across all your devices

### Configuration

#### Popup Quick Settings
- Click the extension icon in your browser toolbar
- Toggle the filter on/off
- Change security level (Confidential/Internal/Restricted)

#### Detailed Settings
- Click "Open Settings" in the popup or go to `chrome://extensions/` and click "Options"
- Configure all settings in the detailed options page
- Add, edit, and delete custom phrases
- Settings are automatically saved and applied across all tabs

### Security Levels

The extension includes three security levels (currently for future implementation):

- **Confidential**: Standard PII detection
- **Internal**: Enhanced detection (future feature)
- **Restricted**: Maximum protection (future feature)

## How It Works

### Detection Method
- Uses **regex patterns** (not LLMs) for fast, reliable detection
- Scans all input fields, textareas, and contenteditable elements
- Monitors for DOM changes to handle dynamic content (SPAs)
- Checks custom phrases against text content

### Redaction Process
1. **Real-time scanning** as you type or paste
2. **Pattern matching** against known PII formats and custom phrases
3. **Automatic replacement** with redacted placeholders
4. **Visual notification** to inform the user

### Technical Details
- **Content Script**: Injected into all web pages
- **Background Service Worker**: Manages settings and state
- **Storage API**: Syncs settings and custom phrases across devices
- **MutationObserver**: Watches for dynamic content changes

## File Structure

```
PII-Filter-Extension/
├── manifest.json          # Extension configuration
├── content.js            # Main PII detection logic
├── background.js         # Service worker
├── popup.html           # Extension popup UI
├── popup.js             # Popup functionality
├── options.html         # Settings page
├── options.js           # Settings management
├── icons/               # Extension icons
│   ├── icon16.png
│   ├── icon48.png
│   └── icon128.png
├── test.html            # Test page
├── debug.html           # Debug page
└── README.md            # This file
```

## Development

### Testing
1. Load the extension in Chrome
2. Navigate to any website with forms
3. Try entering different types of PII
4. Test custom phrases by adding them in settings
5. Verify redaction and notifications work correctly

### Customization
- **Add new PII patterns**: Modify the `PII_PATTERNS` object in `content.js`
- **Change redaction text**: Update the `replacement` values
- **Add custom phrases**: Use the settings page to add your own phrases
- **Modify UI**: Edit the HTML/CSS in popup and options files
- **Add features**: Extend the background script for additional functionality

### Debugging
- Open Chrome DevTools
- Check the Console for any errors
- Use the Extensions page to reload the extension after changes
- Use `debug.html` to test if the extension is loading properly

## Security Considerations

- **Local Processing**: All PII detection happens locally in the browser
- **No Data Collection**: The extension doesn't send any data to external servers
- **Privacy First**: Only redacts content, doesn't store or transmit PII
- **Open Source**: Code is transparent and auditable
- **Custom Phrases**: Stored locally and synced across your devices

## Browser Compatibility

- **Chrome**: Full support (primary target)
- **Edge**: Should work (Chromium-based)
- **Firefox**: May require manifest v2 conversion
- **Safari**: Not supported (different extension API)

## Future Enhancements

- [ ] Implement security level differences
- [ ] Add custom PII pattern configuration
- [ ] Support for additional PII types (passport numbers, etc.)
- [ ] Export/import settings and custom phrases
- [ ] Statistics and usage reports
- [ ] Whitelist specific websites
- [ ] Integration with enterprise SSO
- [ ] Bulk import/export of custom phrases

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

This project is open source and available under the MIT License.

## Support

For issues, questions, or feature requests, please open an issue in the repository.

---

**Note**: This extension is designed to help prevent accidental PII exposure but should not be relied upon as the sole security measure. Always follow your organization's security policies and best practices. 