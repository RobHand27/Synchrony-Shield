// Background service worker for PII Filter Extension

// Handle extension installation
chrome.runtime.onInstalled.addListener((details) => {
    if (details.reason === 'install') {
        // Set default settings on first install
        chrome.storage.sync.set({
            piiFilterEnabled: true,
            securityLevel: 'confidential',
            customPhrases: []
        });
    }
});

// Handle messages from content scripts or popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'getStatus') {
        chrome.storage.sync.get(['piiFilterEnabled', 'securityLevel', 'customPhrases'], (result) => {
            sendResponse({
                enabled: result.piiFilterEnabled !== false,
                securityLevel: result.securityLevel || 'confidential',
                customPhrases: result.customPhrases || []
            });
        });
        return true; // Keep message channel open for async response
    }

    if (request.action === 'setEnabled') {
        chrome.storage.sync.set({ piiFilterEnabled: request.enabled }, () => {
            sendResponse({ success: true });
        });
        return true;
    }

    if (request.action === 'setSecurityLevel') {
        chrome.storage.sync.set({ securityLevel: request.level }, () => {
            sendResponse({ success: true });
        });
        return true;
    }

    if (request.action === 'getCustomPhrases') {
        chrome.storage.sync.get(['customPhrases'], (result) => {
            sendResponse({ customPhrases: result.customPhrases || [] });
        });
        return true;
    }

    if (request.action === 'setCustomPhrases') {
        chrome.storage.sync.set({ customPhrases: request.phrases }, () => {
            sendResponse({ success: true });
        });
        return true;
    }
});

// Handle extension icon click
chrome.action.onClicked.addListener((tab) => {
    // Open options page when icon is clicked
    chrome.runtime.openOptionsPage();
}); 