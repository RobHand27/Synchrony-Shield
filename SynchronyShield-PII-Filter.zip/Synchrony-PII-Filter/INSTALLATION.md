# Installation Guide for PII Filter Extension

## Step 1: Download Zip File

## Step 2: Load Extension in Chrome

1. Open Chrome and navigate to `chrome://extensions/`
2. Enable **Developer Mode** (toggle in top-right corner)
3. Click **"Load unpacked"**
4. Select the folder containing this extension
5. The extension should now appear in your extensions list

## Step 3: Debug the Extension

1. Open `debug.html` in Chrome
2. Check if the extension is loaded (should show "✅ Extension Loaded!")
3. If not loaded, check the browser console for errors
4. Try the test fields to see if PII detection works

## Step 4: Test the Extension

1. Open the `test.html` file in Chrome
2. Try entering PII in the test fields:
   - SSN: `123-45-6789`
   - Email: `test@example.com`
   - Credit card: `4111 1111 1111 1111`
   - Phone: `(123) 456-7890`
3. Watch the redaction happen in real-time

## Step 5: Test with ChatGPT

1. Go to [chat.openai.com](https://chat.openai.com)
2. Try typing PII in the chat input
3. The extension should detect and redact it immediately

## Troubleshooting

### Extension not loading?
1. **Check Chrome Extensions Page**:
   - Go to `chrome://extensions/`
   - Make sure Developer Mode is enabled
   - Look for any error messages
   - Try reloading the extension

2. **Check Browser Console**:
   - Open Developer Tools (F12)
   - Go to Console tab
   - Look for "PII Filter Extension" messages
   - Check for any error messages

3. **Check Manifest Issues**:
   - Make sure all files exist in the correct locations
   - Verify `manifest.json` is valid JSON
   - Check that icon files are actual PNG images

### Extension loaded but not working?
1. **Check if enabled**:
   - Click the extension icon in toolbar
   - Make sure the toggle is ON
   - Check the security level setting

2. **Test with debug page**:
   - Open `debug.html`
   - See if extension logs appear
   - Try the test fields

3. **Check console logs**:
   - Open Developer Tools
   - Look for "PII Filter Extension" messages
   - Should see "Content script loaded" and "Scanning for form fields"

### PII not being detected?
1. **Verify PII formats**:
   - SSN: `123-45-6789` (with dashes)
   - Email: `test@example.com`
   - Credit card: `4111 1111 1111 1111` (with spaces)
   - Phone: `(123) 456-7890`

2. **Check input types**:
   - Try different input fields
   - Test with textarea
   - Test with contenteditable elements

3. **Refresh the page**:
   - Sometimes dynamic content needs a refresh
   - Try reloading the page

### Icons not showing?
- Make sure you saved the PNG files to the `icons/` folder
- The files should be named exactly: `icon16.png`, `icon48.png`, `icon128.png`
- Try regenerating the icons using `generate-icons.html`

## Debug Steps

1. **Open Developer Tools** (F12)
2. **Go to Console tab**
3. **Look for these messages**:
   ```
   PII Filter Extension: Content script loaded
   PII Filter Extension: Settings loaded
   PII Filter Extension: Scanning for form fields
   PII Filter Extension: Found X input fields, Y textareas, Z contenteditable elements
   ```

4. **If you see these messages**, the extension is working
5. **If you don't see these messages**, the extension isn't loading properly

## Features

✅ **Real-time detection** of PII as you type  
✅ **Automatic redaction** with placeholders  
✅ **Works on all websites** including ChatGPT  
✅ **Visual notifications** when PII is detected  
✅ **Toggle on/off** functionality  
✅ **Settings sync** across devices  
✅ **Debug logging** for troubleshooting  

## Supported PII Types

- **Social Security Numbers**: `123-45-6789` → `[REDACTED-SSN]`
- **Email Addresses**: `user@example.com` → `[REDACTED-EMAIL]`
- **Credit Cards**: `4111 1111 1111 1111` → `[REDACTED-CREDIT-CARD]`
- **Phone Numbers**: `(123) 456-7890` → `[REDACTED-PHONE]`
- **Password Fields**: Any input → `[REDACTED-PASSWORD]` 