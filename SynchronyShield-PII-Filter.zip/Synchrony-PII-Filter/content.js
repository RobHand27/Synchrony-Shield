// PII Detection Patterns
const PII_PATTERNS = {
    ssn: {
        regex: /\b\d{3}-\d{2}-\d{4}\b/g,
        replacement: '[REDACTED-SSN]'
    },
    email: {
        regex: /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-z]{2,}/g,
        replacement: '[REDACTED-EMAIL]'
    },
    creditCard: {
        regex: /\b(?:\d[ -]*?){13,16}\b/g,
        replacement: '[REDACTED-CREDIT-CARD]'
    },
    phone: {
        regex: /\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}/g,
        replacement: '[REDACTED-PHONE]'
    }
};

// Custom phrases (will be loaded from storage)
let customPhrases = [];

// Extension state
let isEnabled = true;
let securityLevel = 'confidential';

// Debug logging
console.log('PII Filter Extension: Content script loaded');

// Load settings from storage
chrome.storage.sync.get(['piiFilterEnabled', 'securityLevel', 'customPhrases'], (result) => {
    isEnabled = result.piiFilterEnabled !== false;
    securityLevel = result.securityLevel || 'confidential';
    customPhrases = result.customPhrases || [];
    console.log('PII Filter Extension: Settings loaded', { isEnabled, securityLevel, customPhrasesCount: customPhrases.length });
});

// Listen for settings changes
chrome.storage.onChanged.addListener((changes) => {
    if (changes.piiFilterEnabled) {
        isEnabled = changes.piiFilterEnabled.newValue;
        console.log('PII Filter Extension: Enabled changed to', isEnabled);
    }
    if (changes.securityLevel) {
        securityLevel = changes.securityLevel.newValue;
    }
    if (changes.customPhrases) {
        customPhrases = changes.customPhrases.newValue || [];
        console.log('PII Filter Extension: Custom phrases updated', customPhrases);
    }
});

// Listen for messages from popup/options
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log('PII Filter Extension: Received message', request);

    if (request.action === 'updateStatus') {
        isEnabled = request.enabled;
        sendResponse({ success: true });
    }

    if (request.action === 'updateSecurityLevel') {
        securityLevel = request.level;
        sendResponse({ success: true });
    }

    if (request.action === 'updateSettings') {
        isEnabled = request.enabled;
        securityLevel = request.securityLevel;
        sendResponse({ success: true });
    }

    return true;
});

// Check if text contains PII
function checkPII(text) {
    if (!isEnabled || !text) return null;

    // Check built-in patterns
    for (const [type, pattern] of Object.entries(PII_PATTERNS)) {
        if (pattern.regex.test(text)) {
            console.log('PII Filter Extension: Detected', type, 'in text');
            return { type, pattern };
        }
    }

    // Check custom phrases
    for (const phrase of customPhrases) {
        if (phrase.enabled && phrase.text && text.toLowerCase().includes(phrase.text.toLowerCase())) {
            console.log('PII Filter Extension: Detected custom phrase', phrase.text, 'in text');
            return {
                type: 'custom',
                pattern: {
                    regex: new RegExp(phrase.text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi'),
                    replacement: phrase.replacement || '[REDACTED-CUSTOM]'
                }
            };
        }
    }

    return null;
}

// Replace PII with redacted text
function redactPII(text) {
    if (!isEnabled || !text) return text;

    let redactedText = text;

    // Replace built-in patterns
    for (const [type, pattern] of Object.entries(PII_PATTERNS)) {
        redactedText = redactedText.replace(pattern.regex, pattern.replacement);
    }

    // Replace custom phrases
    for (const phrase of customPhrases) {
        if (phrase.enabled && phrase.text) {
            const regex = new RegExp(phrase.text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');
            redactedText = redactedText.replace(regex, phrase.replacement || '[REDACTED-CUSTOM]');
        }
    }

    return redactedText;
}

// Handle input events
function handleInput(e) {
    if (!isEnabled) return;

    const element = e.target;
    console.log('PII Filter Extension: Input event on', element.tagName, element.type);

    // Special handling for password fields
    if (element.type === 'password' && element.value.length > 0) {
        element.value = '[REDACTED-PASSWORD]';
        showNotification('Password field detected - content redacted');
        return;
    }

    // Check for PII in regular fields
    const originalValue = element.value;
    const piiMatch = checkPII(originalValue);

    if (piiMatch) {
        const redactedValue = redactPII(originalValue);

        // Set the redacted value
        element.value = redactedValue;

        const displayType = piiMatch.type === 'custom' ? 'CUSTOM PHRASE' : piiMatch.type.toUpperCase();
        showNotification(`PII detected: ${displayType} - content redacted`);
    }
}

// Handle contenteditable input
function handleContentEditableInput(e) {
    if (!isEnabled) return;

    const element = e.target;
    console.log('PII Filter Extension: ContentEditable input event');

    const originalText = element.textContent || element.innerText;
    const piiMatch = checkPII(originalText);

    if (piiMatch) {
        const redactedText = redactPII(originalText);

        // Set the redacted text
        element.textContent = redactedText;

        // Move cursor to end
        const range = document.createRange();
        const selection = window.getSelection();
        range.selectNodeContents(element);
        range.collapse(false);
        selection.removeAllRanges();
        selection.addRange(range);

        const displayType = piiMatch.type === 'custom' ? 'CUSTOM PHRASE' : piiMatch.type.toUpperCase();
        showNotification(`PII detected: ${displayType} - content redacted`);
    }
}

// Handle paste events
function handlePaste(e) {
    if (!isEnabled) return;

    const element = e.target;
    const clipboardData = e.clipboardData || window.clipboardData;
    const pastedText = clipboardData.getData('text');

    console.log('PII Filter Extension: Paste event', pastedText);

    // Check if pasted content contains PII
    const piiMatch = checkPII(pastedText);
    if (piiMatch) {
        e.preventDefault();
        e.stopPropagation();

        const redactedText = redactPII(pastedText);

        if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') {
            // For input fields
            const start = element.selectionStart;
            const end = element.selectionEnd;
            const currentValue = element.value;
            element.value = currentValue.substring(0, start) + redactedText + currentValue.substring(end);

            // Set cursor position after the inserted text
            element.setSelectionRange(start + redactedText.length, start + redactedText.length);
        } else if (element.contentEditable === 'true') {
            // For contenteditable elements
            const selection = window.getSelection();
            if (selection.rangeCount > 0) {
                const range = selection.getRangeAt(0);
                range.deleteContents();
                range.insertNode(document.createTextNode(redactedText));
                range.collapse(false);
                selection.removeAllRanges();
                selection.addRange(range);
            }
        }

        const displayType = piiMatch.type === 'custom' ? 'CUSTOM PHRASE' : piiMatch.type.toUpperCase();
        showNotification(`PII detected in pasted content: ${displayType} - content redacted`);
    }
}

// Show notification to user
function showNotification(message) {
    console.log('PII Filter Extension:', message);

    // Remove existing notifications
    const existingNotifications = document.querySelectorAll('.pii-notification');
    existingNotifications.forEach(notification => notification.remove());

    // Create notification element
    const notification = document.createElement('div');
    notification.className = 'pii-notification';
    notification.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    background: #ff4444;
    color: white;
    padding: 12px 16px;
    border-radius: 4px;
    font-family: Arial, sans-serif;
    font-size: 14px;
    z-index: 10000;
    box-shadow: 0 2px 10px rgba(0,0,0,0.3);
    max-width: 300px;
    word-wrap: break-word;
  `;

    // Create notification content
    notification.innerHTML = `
    <div style="margin-bottom: 8px;">${message}</div>
    <div style="font-size: 11px; opacity: 0.9;">
      <button id="learn-more-btn" style="
        background: none;
        border: none;
        color: white;
        text-decoration: underline;
        cursor: pointer;
        font-size: 11px;
        padding: 0;
        margin: 0;
      ">Learn More</button>
    </div>
  `;

    // Add to page
    document.body.appendChild(notification);

    // Add event listener for Learn More button
    const learnMoreBtn = notification.querySelector('#learn-more-btn');
    learnMoreBtn.addEventListener('click', showInfoPopup);

    // Remove after 3 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.parentNode.removeChild(notification);
        }
    }, 3000);
}

// Show information popup
function showInfoPopup() {
    // Remove existing popup
    const existingPopup = document.querySelector('.pii-info-popup');
    if (existingPopup) {
        existingPopup.remove();
    }

    // Create popup overlay
    const overlay = document.createElement('div');
    overlay.className = 'pii-info-popup';
    overlay.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.5);
    z-index: 10001;
    display: flex;
    justify-content: center;
    align-items: center;
  `;

    // Create popup content
    const popup = document.createElement('div');
    popup.style.cssText = `
    background: white;
    border-radius: 8px;
    padding: 30px;
    max-width: 600px;
    max-height: 80vh;
    overflow-y: auto;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
    font-family: Arial, sans-serif;
    line-height: 1.6;
  `;

    popup.innerHTML = `
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
      <h2 style="margin: 0; color: #333;">Information Classifications at Synchrony</h2>
      <button id="close-popup" style="
        background: none;
        border: none;
        font-size: 24px;
        cursor: pointer;
        color: #666;
        padding: 0;
        width: 30px;
        height: 30px;
        display: flex;
        align-items: center;
        justify-content: center;
      ">&times;</button>
    </div>
    
    <p style="margin-bottom: 20px; color: #666;">
      Synchrony classifies information into four main categories based on sensitivity and access controls: 
      <strong>public</strong>, <strong>internal</strong>, <strong>restricted</strong>, and <strong>confidential</strong>. 
      Each classification determines how information should be handled and who is permitted to access it.
    </p>
    
    <h3 style="color: #333; margin-top: 25px; margin-bottom: 15px;">Classification Definitions</h3>
    
    <div style="margin-bottom: 20px;">
      <h4 style="color: #2196F3; margin-bottom: 8px;">Public Information</h4>
      <p style="margin: 0; color: #666;">
        Data that can be freely shared with anyone without risk. No protection is required because disclosure poses no harm to Synchrony or its stakeholders.
      </p>
    </div>
    
    <div style="margin-bottom: 20px;">
      <h4 style="color: #4CAF50; margin-bottom: 8px;">Internal Information</h4>
      <p style="margin: 0; color: #666;">
        Intended for use within Synchrony and its employees. While not highly sensitive, it is not meant for public release. 
        Disclosure outside the organization could be undesirable but typically does not result in significant harm.
      </p>
    </div>
    
    <div style="margin-bottom: 20px;">
      <h4 style="color: #FF9800; margin-bottom: 8px;">Restricted Information</h4>
      <p style="margin: 0; color: #666;">
        Includes data that, if improperly disclosed, could pose a moderate risk to Synchrony, its customers, or partners. 
        Access is limited to specific roles or departments. Examples include proprietary business strategies or non-public financial data.
      </p>
    </div>
    
    <div style="margin-bottom: 20px;">
      <h4 style="color: #F44336; margin-bottom: 8px;">Confidential Information</h4>
      <p style="margin: 0; color: #666;">
        The most sensitive category, including personal data, financial records, or information protected by law or regulation. 
        Unauthorized disclosure could cause significant harm or legal consequences. Strict access controls and robust security measures are required.
      </p>
    </div>
    
    <p style="margin-bottom: 25px; color: #666;">
      These categories help Synchrony ensure that information is handled appropriately based on its sensitivity and the required level of protection.
    </p>
    
    <h3 style="color: #333; margin-bottom: 15px;">Examples of Information Types by Classification</h3>
    
    <div style="background: #f5f5f5; padding: 15px; border-radius: 4px; margin-bottom: 15px;">
      <div style="margin-bottom: 10px;">
        <strong style="color: #2196F3;">Public:</strong>
        <ul style="margin: 5px 0 0 20px; color: #666;">
          <li>Press releases about Synchrony's new products</li>
          <li>Marketing brochures and advertisements</li>
          <li>Publicly available annual reports</li>
        </ul>
      </div>
      
      <div style="margin-bottom: 10px;">
        <strong style="color: #4CAF50;">Internal:</strong>
        <ul style="margin: 5px 0 0 20px; color: #666;">
          <li>Internal staff memos about company procedures</li>
          <li>Employee training materials</li>
          <li>Internal project timelines</li>
        </ul>
      </div>
      
      <div style="margin-bottom: 10px;">
        <strong style="color: #FF9800;">Restricted:</strong>
        <ul style="margin: 5px 0 0 20px; color: #666;">
          <li>Non-public financial statements</li>
          <li>Product development plans not yet released</li>
          <li>Internal audit reports</li>
        </ul>
      </div>
      
      <div>
        <strong style="color: #F44336;">Confidential:</strong>
        <ul style="margin: 5px 0 0 20px; color: #666;">
          <li>Customer Social Security Numbers or account numbers</li>
          <li>Employee medical records or payroll data</li>
          <li>Sensitive legal documents or merger/acquisition plans</li>
        </ul>
      </div>
    </div>
  `;

    // Add close button functionality
    const closeBtn = popup.querySelector('#close-popup');
    closeBtn.addEventListener('click', () => overlay.remove());

    // Close on overlay click
    overlay.addEventListener('click', (e) => {
        if (e.target === overlay) {
            overlay.remove();
        }
    });

    // Close on Escape key
    document.addEventListener('keydown', function closeOnEscape(e) {
        if (e.key === 'Escape') {
            overlay.remove();
            document.removeEventListener('keydown', closeOnEscape);
        }
    });

    overlay.appendChild(popup);
    document.body.appendChild(overlay);
}

// Scan and attach event listeners to form fields
function scanAndAttach() {
    console.log('PII Filter Extension: Scanning for form fields');

    // Get all input fields, textareas, and contenteditable elements
    const inputFields = document.querySelectorAll('input:not([type="password"])');
    const textareas = document.querySelectorAll('textarea');
    const contentEditable = document.querySelectorAll('[contenteditable="true"]');
    const passwordFields = document.querySelectorAll('input[type="password"]');

    console.log('PII Filter Extension: Found', inputFields.length, 'input fields,', textareas.length, 'textareas,', contentEditable.length, 'contenteditable elements');

    // Add event listeners to regular input fields
    inputFields.forEach(field => {
        field.removeEventListener('input', handleInput);
        field.removeEventListener('paste', handlePaste);
        field.addEventListener('input', handleInput);
        field.addEventListener('paste', handlePaste);
    });

    // Add event listeners to textareas
    textareas.forEach(field => {
        field.removeEventListener('input', handleInput);
        field.removeEventListener('paste', handlePaste);
        field.addEventListener('input', handleInput);
        field.addEventListener('paste', handlePaste);
    });

    // Add event listeners to contenteditable elements
    contentEditable.forEach(field => {
        field.removeEventListener('input', handleContentEditableInput);
        field.removeEventListener('paste', handlePaste);
        field.addEventListener('input', handleContentEditableInput);
        field.addEventListener('paste', handlePaste);
    });

    // Special handling for password fields
    passwordFields.forEach(field => {
        field.removeEventListener('input', handleInput);
        field.addEventListener('input', handleInput);
    });
}

// Wait for DOM to be ready
function initialize() {
    console.log('PII Filter Extension: Initializing');

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => {
            scanAndAttach();
        });
    } else {
        scanAndAttach();
    }
}

// Initialize immediately
initialize();

// Watch for DOM changes (for SPAs and dynamic content)
const observer = new MutationObserver((mutations) => {
    let shouldRescan = false;

    mutations.forEach((mutation) => {
        if (mutation.type === 'childList') {
            mutation.addedNodes.forEach((node) => {
                if (node.nodeType === Node.ELEMENT_NODE) {
                    // Check if added node is a form field or contains form fields
                    if (node.matches && (
                        node.matches('input, textarea, [contenteditable="true"]') ||
                        node.querySelector('input, textarea, [contenteditable="true"]')
                    )) {
                        shouldRescan = true;
                    }
                }
            });
        }
    });

    if (shouldRescan) {
        console.log('PII Filter Extension: DOM changed, rescanning');
        setTimeout(scanAndAttach, 100);
    }
});

// Start observing
observer.observe(document.body, {
    childList: true,
    subtree: true
});

// Periodic rescan for dynamic content (like ChatGPT)
setInterval(() => {
    if (isEnabled) {
        scanAndAttach();
    }
}, 3000); // Rescan every 3 seconds

console.log('PII Filter Extension: Content script initialization complete'); 