// Popup script for PII Filter Extension

document.addEventListener('DOMContentLoaded', () => {
    const enableToggle = document.getElementById('enableToggle');
    const levelButtons = document.querySelectorAll('.level-btn');
    const openOptionsLink = document.getElementById('openOptions');

    // Load current settings
    loadSettings();

    // Event listeners
    enableToggle.addEventListener('change', handleToggleChange);
    levelButtons.forEach(btn => {
        btn.addEventListener('click', handleLevelChange);
    });
    openOptionsLink.addEventListener('click', openOptions);

    // Load settings from storage
    function loadSettings() {
        chrome.runtime.sendMessage({ action: 'getStatus' }, (response) => {
            if (response) {
                enableToggle.checked = response.enabled;
                updateLevelButtons(response.securityLevel);
            }
        });
    }

    // Handle toggle change
    function handleToggleChange() {
        const enabled = enableToggle.checked;
        chrome.runtime.sendMessage({
            action: 'setEnabled',
            enabled: enabled
        }, (response) => {
            if (response && response.success) {
                // Update all tabs
                chrome.tabs.query({}, (tabs) => {
                    tabs.forEach(tab => {
                        chrome.tabs.sendMessage(tab.id, {
                            action: 'updateStatus',
                            enabled: enabled
                        }).catch(() => {
                            // Ignore errors for tabs that don't have content scripts
                        });
                    });
                });
            }
        });
    }

    // Handle security level change
    function handleLevelChange(e) {
        const level = e.target.dataset.level;
        chrome.runtime.sendMessage({
            action: 'setSecurityLevel',
            level: level
        }, (response) => {
            if (response && response.success) {
                updateLevelButtons(level);

                // Update all tabs
                chrome.tabs.query({}, (tabs) => {
                    tabs.forEach(tab => {
                        chrome.tabs.sendMessage(tab.id, {
                            action: 'updateSecurityLevel',
                            level: level
                        }).catch(() => {
                            // Ignore errors for tabs that don't have content scripts
                        });
                    });
                });
            }
        });
    }

    // Update level button states
    function updateLevelButtons(activeLevel) {
        levelButtons.forEach(btn => {
            btn.classList.remove('active');
            if (btn.dataset.level === activeLevel) {
                btn.classList.add('active');
            }
        });
    }

    // Open options page
    function openOptions(e) {
        e.preventDefault();
        chrome.runtime.openOptionsPage();
    }
}); 