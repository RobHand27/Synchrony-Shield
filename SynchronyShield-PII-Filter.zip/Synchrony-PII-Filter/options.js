// Options page script for PII Filter Extension

document.addEventListener('DOMContentLoaded', () => {
    const enableToggle = document.getElementById('enableToggle');
    const levelButtons = document.querySelectorAll('.level-btn');
    const saveButton = document.getElementById('saveButton');
    const statusMessage = document.getElementById('statusMessage');

    // Custom phrases elements
    const phraseTextInput = document.getElementById('phraseText');
    const phraseReplacementInput = document.getElementById('phraseReplacement');
    const addPhraseBtn = document.getElementById('addPhraseBtn');
    const clearFormBtn = document.getElementById('clearFormBtn');
    const phrasesList = document.getElementById('phrasesList');

    // Load current settings
    loadSettings();

    // Event listeners
    enableToggle.addEventListener('change', handleSettingChange);
    levelButtons.forEach(btn => {
        btn.addEventListener('click', handleLevelChange);
    });
    saveButton.addEventListener('click', saveSettings);

    // Custom phrases event listeners
    addPhraseBtn.addEventListener('click', addCustomPhrase);
    clearFormBtn.addEventListener('click', clearForm);

    // Event delegation for phrases list
    phrasesList.addEventListener('click', handlePhraseAction);

    // Load settings from storage
    function loadSettings() {
        chrome.storage.sync.get(['piiFilterEnabled', 'securityLevel', 'customPhrases'], (result) => {
            enableToggle.checked = result.piiFilterEnabled !== false; // Default to true
            updateLevelButtons(result.securityLevel || 'confidential');
            updatePhrasesList(result.customPhrases || []);
        });
    }

    // Handle toggle change
    function handleSettingChange() {
        // Settings are saved automatically, no need for explicit save
        showStatusMessage('Settings updated automatically', 'success');
    }

    // Handle security level change
    function handleLevelChange(e) {
        const level = e.target.dataset.level;
        updateLevelButtons(level);
        showStatusMessage('Security level updated', 'success');
    }

    // Update level button states
    function updateLevelButtons(activeLevel) {
        levelButtons.forEach(btn => {
            btn.classList.remove('active');
            if (btn.dataset.level === activeLevel) {
                btn.classList.add('active');
            }
        });
    }

    // Add custom phrase
    function addCustomPhrase() {
        const phraseText = phraseTextInput.value.trim();
        const replacement = phraseReplacementInput.value.trim();

        if (!phraseText) {
            showStatusMessage('Please enter a phrase to filter', 'error');
            return;
        }

        // Load current phrases
        chrome.storage.sync.get(['customPhrases'], (result) => {
            const currentPhrases = result.customPhrases || [];

            // Check if phrase already exists
            const existingIndex = currentPhrases.findIndex(p => p.text.toLowerCase() === phraseText.toLowerCase());

            if (existingIndex !== -1) {
                // Update existing phrase
                currentPhrases[existingIndex] = {
                    text: phraseText,
                    replacement: replacement || '[REDACTED-CUSTOM]',
                    enabled: true
                };
                showStatusMessage('Phrase updated successfully', 'success');
            } else {
                // Add new phrase
                currentPhrases.push({
                    text: phraseText,
                    replacement: replacement || '[REDACTED-CUSTOM]',
                    enabled: true
                });
                showStatusMessage('Phrase added successfully', 'success');
            }

            // Save to storage
            chrome.storage.sync.set({ customPhrases: currentPhrases }, () => {
                updatePhrasesList(currentPhrases);
                clearForm();
            });
        });
    }

    // Clear form
    function clearForm() {
        phraseTextInput.value = '';
        phraseReplacementInput.value = '[REDACTED-CUSTOM]';
    }

    // Handle phrase actions (edit/delete) using event delegation
    function handlePhraseAction(e) {
        const target = e.target;

        if (target.classList.contains('btn-edit')) {
            const index = parseInt(target.dataset.index);
            editPhrase(index);
        } else if (target.classList.contains('btn-delete')) {
            const index = parseInt(target.dataset.index);
            deletePhrase(index);
        }
    }

    // Update phrases list display
    function updatePhrasesList(phrases) {
        phrasesList.innerHTML = '';

        if (phrases.length === 0) {
            phrasesList.innerHTML = '<p style="color: #666; font-style: italic;">No custom phrases added yet.</p>';
            return;
        }

        phrases.forEach((phrase, index) => {
            const phraseItem = document.createElement('div');
            phraseItem.className = 'phrase-item';
            phraseItem.innerHTML = `
        <div>
          <div class="phrase-text">${phrase.text}</div>
          <div class="phrase-replacement">Replacement: ${phrase.replacement}</div>
        </div>
        <div class="phrase-actions">
          <button class="btn btn-secondary btn-edit" data-index="${index}">Edit</button>
          <button class="btn btn-danger btn-delete" data-index="${index}">Delete</button>
        </div>
      `;
            phrasesList.appendChild(phraseItem);
        });
    }

    // Edit phrase
    function editPhrase(index) {
        chrome.storage.sync.get(['customPhrases'], (result) => {
            const phrases = result.customPhrases || [];
            const phrase = phrases[index];

            if (phrase) {
                phraseTextInput.value = phrase.text;
                phraseReplacementInput.value = phrase.replacement;
                phraseTextInput.focus();
            }
        });
    }

    // Delete phrase
    function deletePhrase(index) {
        if (confirm('Are you sure you want to delete this phrase?')) {
            chrome.storage.sync.get(['customPhrases'], (result) => {
                const phrases = result.customPhrases || [];
                phrases.splice(index, 1);

                chrome.storage.sync.set({ customPhrases: phrases }, () => {
                    updatePhrasesList(phrases);
                    showStatusMessage('Phrase deleted successfully', 'success');
                });
            });
        }
    }

    // Save settings
    function saveSettings() {
        const enabled = enableToggle.checked;
        const activeLevel = document.querySelector('.level-btn.active').dataset.level;

        chrome.storage.sync.set({
            piiFilterEnabled: enabled,
            securityLevel: activeLevel
        }, () => {
            if (chrome.runtime.lastError) {
                showStatusMessage('Error saving settings: ' + chrome.runtime.lastError.message, 'error');
            } else {
                showStatusMessage('Settings saved successfully!', 'success');

                // Update all tabs with new settings
                chrome.tabs.query({}, (tabs) => {
                    tabs.forEach(tab => {
                        chrome.tabs.sendMessage(tab.id, {
                            action: 'updateSettings',
                            enabled: enabled,
                            securityLevel: activeLevel
                        }).catch(() => {
                            // Ignore errors for tabs that don't have content scripts
                        });
                    });
                });
            }
        });
    }

    // Show status message
    function showStatusMessage(message, type) {
        statusMessage.textContent = message;
        statusMessage.className = `status-message ${type}`;

        // Clear message after 3 seconds
        setTimeout(() => {
            statusMessage.textContent = '';
            statusMessage.className = '';
        }, 3000);
    }

    // Auto-save settings when they change
    function autoSave() {
        const enabled = enableToggle.checked;
        const activeLevel = document.querySelector('.level-btn.active').dataset.level;

        chrome.storage.sync.set({
            piiFilterEnabled: enabled,
            securityLevel: activeLevel
        }, () => {
            if (!chrome.runtime.lastError) {
                // Update all tabs
                chrome.tabs.query({}, (tabs) => {
                    tabs.forEach(tab => {
                        chrome.tabs.sendMessage(tab.id, {
                            action: 'updateSettings',
                            enabled: enabled,
                            securityLevel: activeLevel
                        }).catch(() => {
                            // Ignore errors for tabs that don't have content scripts
                        });
                    });
                });
            }
        });
    }

    // Add auto-save listeners
    enableToggle.addEventListener('change', autoSave);
    levelButtons.forEach(btn => {
        btn.addEventListener('click', autoSave);
    });
}); 